<?php
//$fname = '' . ROOT . 'app' . DS . 'config' . DS . 'config.php';

$fname = "h2name" . ".csv"
$fhandle = fopen($fname,"r");
$content = fread($fhandle,filesize($fname));
while (!feof($fhandle)) {
  $contenLine = fgets($fhandle);
  $domeniu = substr($contenLine, 1, "-");
  $intrebare = substr($contenLine, strlen($domeniu."-"), ":");
  $rasp1 = substr($contenLine, strlen($domeniu.$intrebare)+2, ",");
  //....
}

$nrIntrebari = 0;
$intrebariSelectate = array();
$q_idArray = array();
while ($nrIntrebari < 10) {
  $querrygetquestion = 'Select * from INTREBARI WHERE DOMENIU NOT IN (' . join(', ', $intrebariSelectate) . ')';
  // try {
  $result = oci_execute(oci_parse($connection, $querrygetquestion));
  $intrebariSelectate = array_push(oci_fetch($result->DOMENIU));
  $q_idArray = array_push(oci_fetch($result->ID));
}

forEach ($intrebariSelectate as $intrebare)
{
  $nrRaspOk = rand(1,3);
  $nrRaspBad = rand(2,5-$nrRaspOk);
  $arrRaspOk = array();
  $arrRaspBad = array();
  while($nrRaspOk > 0) {
    $querrygetanswOK = 'Select * from RASPUNSURI WHERE ID NOT IN (' . join(',', $arrRaspOk) . ') AND Q_ID = ' . $intrebare . ' AND CORECT = 1';
    $result = oci_execute(oci_parse($connection, $querrygetanswOK));
    $arrRaspOk = array_push(oci_fetch($result->ID));
  }
  while($nrRaspBad > 0) {
    $querrygetanswBad = 'Select * from RASPUNSURI WHERE ID NOT IN (' . join(',', $arrRaspBad) . ') AND Q_ID = ' . $intrebare . ' AND CORECT = 0';
    $result = oci_execute(oci_parse($connection, $querrygetanswBad));
    $arrRaspBad = array_push(oci_fetch($result->ID));
  }
}



//contentLine1: D1-q1:a7,a2,a5,a3,a9
//contentLine1: D3-q2:a5,a9....
//contentLine1: ...
//contentLine1: ...
//contentLine1: ...
//contentLine1: ...
//contentLine1: ...
//contentLine1: ...
//contentLine1: ...
//contentLine1: ...
//$content = str_replace("'INSTALLED', false);", "'INSTALLED', true);\nDEFINE('PLSQL_DRIVER', 'oci8');", $content);

$fhandle = fopen($fname,"w");
fwrite($fhandle,$content);
fclose($fhandle);





?>